package com.courses.service;

import java.util.List;

import com.courses.model.Course;



public interface IServiceCourse {

	public List<Course> findAll();
	public void save(Course course);
	public void deleteById(Long id);
}
