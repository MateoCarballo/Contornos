package com.courses.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.courses.model.Course;
import com.courses.repository.CoursesRepository;

@Service
public class ServiceCourseImpl implements IServiceCourse{


	@Autowired
	private CoursesRepository repository;

	@Override
	public List<Course> findAll() {
		return (List<Course>) repository.findAll();
	}
	
	@Override
	public void deleteById(Long id) {
		//TO DO
	}

	@Override
	public void save(Course course) {
		//TO DO
	}
	
}
