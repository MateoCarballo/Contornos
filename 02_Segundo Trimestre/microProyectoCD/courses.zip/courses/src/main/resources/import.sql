INSERT INTO cursos (name, scope) VALUES ('Sistemas electrónicos', 'Industry');
INSERT INTO cursos (name, scope) VALUES ('Autocad', 'Industry');
INSERT INTO cursos (name, scope) VALUES ('Mecánica', 'Industry');
INSERT INTO cursos (name, scope) VALUES ('Desarrollo Web', 'IT');
INSERT INTO cursos (name, scope) VALUES ('Sistemas informáticos', 'IT');
INSERT INTO cursos (name, scope) VALUES ('Excel avanzado', 'IT');
INSERT INTO cursos (name, scope) VALUES ('Análisis clínico', 'Chemistry');