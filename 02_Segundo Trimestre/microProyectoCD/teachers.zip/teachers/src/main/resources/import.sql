INSERT INTO profesores (firstname, lastname, course) VALUES ('Hector', 'Tapia', 'Excel avanzado');
INSERT INTO profesores (firstname, lastname, course) VALUES ('Maria', 'Rodríguez', 'Autocad');
INSERT INTO profesores (firstname, lastname, course) VALUES ('Pedro', 'Marín', 'Autocad');
INSERT INTO profesores (firstname, lastname, course) VALUES ('Claudia', 'Vázquez', 'Sistemas Informáticos');
INSERT INTO profesores (firstname, lastname, course) VALUES ('Hernán', 'Cortés', 'Desarrollo Web');
INSERT INTO profesores (firstname, lastname, course) VALUES ('Débora', 'Redondo', 'Sistemas Informáticos');
INSERT INTO profesores (firstname, lastname, course) VALUES ('Itxel', 'Fernández', 'Desarrollo Web');
INSERT INTO profesores (firstname, lastname, course) VALUES ('Rebeca', 'Hervella', 'Sistemas Informáticos');
INSERT INTO profesores (firstname, lastname, course) VALUES ('Nora', 'Fernández', 'Análisis clínico');