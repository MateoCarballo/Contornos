package com.students.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.students.model.Alumno;
import com.students.repository.AlumnosRepository;

@Service
public class ServiceAlumnoImpl implements IServiceAlumno{


	@Autowired
	private AlumnosRepository repository;

	@Override
	public List<Alumno> findAll() {
		return (List<Alumno>) repository.findAll();
	}

	@Override
	public void deleteById(Long id) {
		//TO DO
	}

	@Override
	public void save(Alumno alumno) {
		//TO DO
	}

}
