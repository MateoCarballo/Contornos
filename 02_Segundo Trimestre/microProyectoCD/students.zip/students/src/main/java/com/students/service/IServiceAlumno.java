package com.students.service;

import java.util.List;

import com.students.model.Alumno;



public interface IServiceAlumno {

	public List<Alumno> findAll();
	public void save(Alumno alumno);
	public void deleteById(Long id);
}
