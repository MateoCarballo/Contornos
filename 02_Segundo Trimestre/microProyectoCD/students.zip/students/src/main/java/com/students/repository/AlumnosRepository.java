package com.students.repository;

import org.springframework.data.repository.CrudRepository;

import com.students.model.Alumno;

public interface AlumnosRepository extends CrudRepository<Alumno, Long>{

}
